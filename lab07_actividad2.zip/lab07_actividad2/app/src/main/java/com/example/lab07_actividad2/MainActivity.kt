package com.example.lab07_actividad2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var txtCodigo: EditText
    private lateinit var txtDescripcion: EditText
    private lateinit var txtPrecio: EditText
    private lateinit var txtLista: TextView

    private lateinit var btnRegistrar: Button
    private lateinit var btnBuscar: Button
    private lateinit var btnModificar: Button
    private lateinit var btnEliminar: Button

    private lateinit var repository: ArticuloRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val dao = AppDatabase.getInstance(this).articuloDao()
        repository = ArticuloRepository(dao)

        txtCodigo = findViewById(R.id.txtCodigo)
        txtDescripcion = findViewById(R.id.txtDescripcion)
        txtPrecio = findViewById(R.id.txtPrecio)
        txtLista = findViewById(R.id.txtLista)

        btnRegistrar = findViewById(R.id.btnRegistrar)
        btnBuscar = findViewById(R.id.btnBuscar)
        btnModificar = findViewById(R.id.btnModificar)
        btnEliminar = findViewById(R.id.btnEliminar)

        btnRegistrar.setOnClickListener {
            registrar()
        }

        btnBuscar.setOnClickListener {
            buscar()
        }

        btnModificar.setOnClickListener {
            modificar()
        }

        btnEliminar.setOnClickListener {
            eliminar()
        }

        observarLista()
    }

    private fun registrar() {
        val codigo = txtCodigo.text.toString().trim().toIntOrNull()
        val descripcion = txtDescripcion.text.toString().trim()
        val precio = txtPrecio.text.toString().trim().toDoubleOrNull()

        if (codigo == null || descripcion.isEmpty() || precio == null) {
            toast("Debe llenar todos los campos correctamente")
            return
        }

        val articulo = Articulo(
            codigo = codigo,
            descripcion = descripcion,
            precio = precio
        )

        lifecycleScope.launch {
            try {
                repository.registrar(articulo)
                limpiarCampos()
                toast("Producto registrado correctamente")
            } catch (e: Exception) {
                toast("Error: el código ya existe")
            }
        }
    }

    private fun buscar() {
        val codigo = txtCodigo.text.toString().trim().toIntOrNull()

        if (codigo == null) {
            toast("Debe ingresar un código válido")
            return
        }

        lifecycleScope.launch {
            val articulo = repository.buscar(codigo)

            if (articulo != null) {
                txtDescripcion.setText(articulo.descripcion)
                txtPrecio.setText(articulo.precio.toString())
                toast("Producto encontrado")
            } else {
                toast("No existe el producto")
            }
        }
    }

    private fun modificar() {
        val codigo = txtCodigo.text.toString().trim().toIntOrNull()
        val descripcion = txtDescripcion.text.toString().trim()
        val precio = txtPrecio.text.toString().trim().toDoubleOrNull()

        if (codigo == null || descripcion.isEmpty() || precio == null) {
            toast("Debe llenar todos los campos correctamente")
            return
        }

        val articulo = Articulo(
            codigo = codigo,
            descripcion = descripcion,
            precio = precio
        )

        lifecycleScope.launch {
            val filas = repository.modificar(articulo)

            if (filas == 1) {
                limpiarCampos()
                toast("Producto modificado correctamente")
            } else {
                toast("El producto no existe")
            }
        }
    }

    private fun eliminar() {
        val codigo = txtCodigo.text.toString().trim().toIntOrNull()

        if (codigo == null) {
            toast("Debe ingresar un código válido")
            return
        }

        lifecycleScope.launch {
            val filas = repository.eliminar(codigo)

            if (filas == 1) {
                limpiarCampos()
                toast("Producto eliminado correctamente")
            } else {
                toast("El producto no existe")
            }
        }
    }

    private fun observarLista() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repository.listaArticulos.collect { lista ->

                    if (lista.isEmpty()) {
                        txtLista.text = "Sin registros"
                    } else {
                        txtLista.text = lista.joinToString("\n") { articulo ->
                            "Código: ${articulo.codigo} | ${articulo.descripcion} | S/ ${articulo.precio}"
                        }
                    }
                }
            }
        }
    }

    private fun limpiarCampos() {
        txtCodigo.setText("")
        txtDescripcion.setText("")
        txtPrecio.setText("")
    }

    private fun toast(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }
}