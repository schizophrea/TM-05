package com.example.lab07_actividad2

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "articulos")
data class Articulo(
    @PrimaryKey
    val codigo: Int,
    val descripcion: String,
    val precio: Double
)