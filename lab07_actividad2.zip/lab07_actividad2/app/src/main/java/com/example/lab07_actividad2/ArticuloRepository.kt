package com.example.lab07_actividad2

import kotlinx.coroutines.flow.Flow

class ArticuloRepository(
    private val dao: ArticuloDao
) {

    val listaArticulos: Flow<List<Articulo>> = dao.listarTodos()

    suspend fun registrar(articulo: Articulo): Long {
        return dao.insertar(articulo)
    }

    suspend fun buscar(codigo: Int): Articulo? {
        return dao.buscarPorCodigo(codigo)
    }

    suspend fun modificar(articulo: Articulo): Int {
        return dao.actualizar(articulo)
    }

    suspend fun eliminar(codigo: Int): Int {
        return dao.eliminarPorCodigo(codigo)
    }
}