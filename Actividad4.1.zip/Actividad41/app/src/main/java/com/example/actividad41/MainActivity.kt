package com.example.actividad41

import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.TimePicker
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnHora = findViewById<Button>(R.id.btnHora)
        val datePicker = findViewById<DatePicker>(R.id.datePicker)
        val timePicker = findViewById<TimePicker>(R.id.timePicker)

        timePicker.setIs24HourView(true)

        btnHora.setOnClickListener {
            val dia = datePicker.dayOfMonth
            val mes = datePicker.month + 1
            val anio = datePicker.year

            val hora: Int
            val minuto: Int

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                hora = timePicker.hour
                minuto = timePicker.minute
            } else {
                hora = timePicker.currentHour
                minuto = timePicker.currentMinute
            }

            val fechaTexto = String.format("%02d/%02d/%04d", dia, mes, anio)
            val horaTexto = String.format("%02d:%02d", hora, minuto)

            val calendario = Calendar.getInstance()
            calendario.set(anio, mes - 1, dia)

            val diaSemana = calendario.get(Calendar.DAY_OF_WEEK)

            val apto = (diaSemana != Calendar.SATURDAY &&
                    diaSemana != Calendar.SUNDAY &&
                    hora in 8..16)

            val mensaje = if (apto) {
                "Fecha: $fechaTexto\nHora: $horaTexto\n\n APTO"
            } else {
                "Fecha: $fechaTexto\nHora: $horaTexto\n\n NO APTO"
            }

            AlertDialog.Builder(this)
                .setTitle("Resultado de evaluación")
                .setMessage(mensaje)
                .setPositiveButton("Aceptar", null)
                .show()
        }
    }
}