package com.example.ejercicio5

import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray

class ListaProductosActivity : AppCompatActivity() {

    private lateinit var edtBuscar: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnVolver: Button
    private lateinit var btnLimpiar: Button

    private lateinit var adapter: ProductoAdapter
    private lateinit var prefs: SharedPreferences

    private val listaCompleta = mutableListOf<Producto>()
    private val listaFiltrada = mutableListOf<Producto>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_productos)

        edtBuscar = findViewById(R.id.edtBuscar)
        recyclerView = findViewById(R.id.recyclerViewProductos)
        btnVolver = findViewById(R.id.btnVolver)
        btnLimpiar = findViewById(R.id.btnLimpiar)

        prefs = getSharedPreferences("catalogo_productos_prefs", MODE_PRIVATE)

        adapter = ProductoAdapter(listaFiltrada)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        cargarProductos()
        filtrarProductos("")

        edtBuscar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filtrarProductos(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnVolver.setOnClickListener {
            finish()
        }

        btnLimpiar.setOnClickListener {
            prefs.edit().remove("productos_json").apply()
            listaCompleta.clear()
            listaFiltrada.clear()
            adapter.actualizarLista(listaFiltrada)
            Toast.makeText(this, "Catálogo eliminado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cargarProductos() {
        val json = prefs.getString("productos_json", null)

        if (!json.isNullOrEmpty()) {
            try {
                val jsonArray = JSONArray(json)
                listaCompleta.clear()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val producto = Producto(
                        obj.getString("nombre"),
                        obj.getInt("cantidad"),
                        obj.getDouble("precio")
                    )
                    listaCompleta.add(producto)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Error al cargar productos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun filtrarProductos(texto: String) {
        val textoBusqueda = texto.trim().lowercase()

        val resultados = if (textoBusqueda.isEmpty()) {
            listaCompleta
        } else {
            listaCompleta.filter {
                it.nombre.lowercase().contains(textoBusqueda)
            }
        }

        listaFiltrada.clear()
        listaFiltrada.addAll(resultados)
        adapter.actualizarLista(listaFiltrada)
    }
}