package com.example.ejercicio5

data class Producto(
    val nombre: String,
    val cantidad: Int,
    val precio: Double
)