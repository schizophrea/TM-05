package com.example.ejercicio5

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var edtNombre: EditText
    private lateinit var edtCantidad: EditText
    private lateinit var edtPrecio: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnVerCatalogo: Button

    private lateinit var prefs: SharedPreferences
    private val listaProductos = mutableListOf<Producto>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtNombre = findViewById(R.id.edtNombre)
        edtCantidad = findViewById(R.id.edtCantidad)
        edtPrecio = findViewById(R.id.edtPrecio)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnVerCatalogo = findViewById(R.id.btnVerCatalogo)

        prefs = getSharedPreferences("catalogo_productos_prefs", MODE_PRIVATE)

        cargarProductos()

        btnGuardar.setOnClickListener {
            guardarProducto()
        }

        btnVerCatalogo.setOnClickListener {
            startActivity(Intent(this, ListaProductosActivity::class.java))
        }
    }

    private fun guardarProducto() {
        val nombre = edtNombre.text.toString().trim()
        val cantidadTexto = edtCantidad.text.toString().trim()
        val precioTexto = edtPrecio.text.toString().trim()

        if (nombre.isEmpty() || cantidadTexto.isEmpty() || precioTexto.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val cantidad = cantidadTexto.toIntOrNull()
        val precio = precioTexto.toDoubleOrNull()

        if (cantidad == null || cantidad <= 0) {
            Toast.makeText(this, "Ingresa una cantidad válida", Toast.LENGTH_SHORT).show()
            return
        }

        if (precio == null || precio <= 0) {
            Toast.makeText(this, "Ingresa un precio válido", Toast.LENGTH_SHORT).show()
            return
        }

        val producto = Producto(nombre, cantidad, precio)
        listaProductos.add(producto)
        guardarProductosEnPrefs()

        edtNombre.text.clear()
        edtCantidad.text.clear()
        edtPrecio.text.clear()

        Toast.makeText(this, "Producto guardado", Toast.LENGTH_SHORT).show()

        startActivity(Intent(this, ListaProductosActivity::class.java))
    }

    private fun guardarProductosEnPrefs() {
        val jsonArray = JSONArray()

        for (producto in listaProductos) {
            val jsonObject = JSONObject()
            jsonObject.put("nombre", producto.nombre)
            jsonObject.put("cantidad", producto.cantidad)
            jsonObject.put("precio", producto.precio)
            jsonArray.put(jsonObject)
        }

        prefs.edit().putString("productos_json", jsonArray.toString()).apply()
    }

    private fun cargarProductos() {
        val json = prefs.getString("productos_json", null)

        if (!json.isNullOrEmpty()) {
            try {
                val jsonArray = JSONArray(json)
                listaProductos.clear()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val producto = Producto(
                        obj.getString("nombre"),
                        obj.getInt("cantidad"),
                        obj.getDouble("precio")
                    )
                    listaProductos.add(producto)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Error al cargar productos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}