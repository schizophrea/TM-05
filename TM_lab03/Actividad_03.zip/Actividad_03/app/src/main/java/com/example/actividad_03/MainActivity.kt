package com.example.actividad_03

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val TAG = "Ciclo de Vida"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(TAG, "En el evento onCreate()")
    }

    fun onClick(view: View) {
        val intent = Intent(this, SegundaActividad::class.java)
        startActivity(intent)
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "En el evento onStart()")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "En el evento onRestart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "En el evento onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "En el evento onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "En el evento onStop()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "En el evento onDestroy()")
    }
}