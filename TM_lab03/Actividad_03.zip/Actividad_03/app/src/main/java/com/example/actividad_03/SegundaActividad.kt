package com.example.actividad_03

import android.os.Bundle
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity

class SegundaActividad : AppCompatActivity() {

    private val TIMER_RUNTIME = 10000
    private var nbActivo = false
    private lateinit var nProgressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_actividad)

        nProgressBar = findViewById(R.id.progressBar)

        val timerThread = Thread {
            nbActivo = true
            try {
                var espera1 = 0

                while (nbActivo && espera1 < TIMER_RUNTIME) {
                    Thread.sleep(200)

                    if (nbActivo) {
                        espera1 += 200
                        actualizarProgress(espera1)
                    }
                }

            } catch (e: InterruptedException) {
                e.printStackTrace()
            } finally {
                onContinuar()
            }
        }

        timerThread.start()
    }

    private fun actualizarProgress(timePassed: Int) {
        if (::nProgressBar.isInitialized) {
            val progress = nProgressBar.max * timePassed / TIMER_RUNTIME

            runOnUiThread {
                nProgressBar.progress = progress
            }
        }
    }

    private fun onContinuar() {
        // Aquí puedes poner lo que quieres que pase al terminar
        // Ejemplo: volver a la actividad principal
        finish()
    }
}