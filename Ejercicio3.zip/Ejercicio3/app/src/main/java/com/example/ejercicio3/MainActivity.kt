package com.example.ejercicio3

import android.os.Bundle
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var gridView: GridView

    private val nombresPizza = arrayOf(
        "Pizza Pepperoni",
        "Pizza Hawaiana",
        "Pizza Americana",
        "Pizza Vegetariana"
    )

    private val imagenesPizza = intArrayOf(
        R.drawable.pepperoni,
        R.drawable.hawaiana,
        R.drawable.americana,
        R.drawable.vegetariana
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridView = findViewById(R.id.gridViewPizzas)

        val adapter = PizzaAdapter(this, nombresPizza, imagenesPizza)
        gridView.adapter = adapter

        gridView.onItemClickListener =
            AdapterView.OnItemClickListener { _, _, position, _ ->
                Toast.makeText(this, nombresPizza[position], Toast.LENGTH_SHORT).show()
            }
    }
}