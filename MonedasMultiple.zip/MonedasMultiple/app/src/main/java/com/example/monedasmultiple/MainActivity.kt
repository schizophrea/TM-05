package com.example.monedasmultiple

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etCantidad: EditText
    private lateinit var spOrigen: Spinner
    private lateinit var spDestino: Spinner
    private lateinit var btnConvertir: Button
    private lateinit var tvResultado: TextView

    // Valores base respecto al dólar (USD)
    private val tasas = mapOf(
        "USD - Dólar" to 1.0,
        "PEN - Sol" to 3.45,
        "EUR - Euro" to 0.86,
        "GBP - Libra Esterlina" to 0.74,
        "INR - Rupia" to 93.08,
        "BRL - Real" to 5.22,
        "MXN - Peso Mexicano" to 17.75,
        "CNY - Yuan" to 6.9,
        "JPY - Yen" to 157.96
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCantidad = findViewById(R.id.etCantidad)
        spOrigen = findViewById(R.id.spOrigen)
        spDestino = findViewById(R.id.spDestino)
        btnConvertir = findViewById(R.id.btnConvertir)
        tvResultado = findViewById(R.id.tvResultado)

        val monedas = tasas.keys.toList()

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            monedas
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        spOrigen.adapter = adapter
        spDestino.adapter = adapter

        btnConvertir.setOnClickListener {
            convertirMoneda()
        }
    }

    private fun convertirMoneda() {
        val cantidadTexto = etCantidad.text.toString()

        if (cantidadTexto.isEmpty()) {
            Toast.makeText(this, "Ingrese una cantidad", Toast.LENGTH_SHORT).show()
            return
        }

        val cantidad = cantidadTexto.toDouble()
        val monedaOrigen = spOrigen.selectedItem.toString()
        val monedaDestino = spDestino.selectedItem.toString()

        val tasaOrigen = tasas[monedaOrigen] ?: 1.0
        val tasaDestino = tasas[monedaDestino] ?: 1.0

        // Convertir primero a dólares y luego a la moneda destino
        val cantidadEnDolares = cantidad / tasaOrigen
        val resultado = cantidadEnDolares * tasaDestino

        tvResultado.text = "Resultado: %.2f %s".format(
            resultado,
            monedaDestino.substringBefore(" -")
        )
    }
}