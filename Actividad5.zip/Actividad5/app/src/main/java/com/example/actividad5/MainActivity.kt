package com.example.actividad5

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var txtString: EditText
    private lateinit var prefs: SharedPreferences
    private lateinit var imageView: ImageView

    private val imagenes = intArrayOf(
        R.drawable.pic01,
        R.drawable.pic02,
        R.drawable.pic03,
        R.drawable.pic04,
        R.drawable.pic05,
        R.drawable.pic06,
        R.drawable.pic07
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtString = findViewById(R.id.txtString)
        imageView = findViewById(R.id.imageView)

        prefs = getSharedPreferences(
            "com.norbel.usopreferencias_preferences",
            MODE_PRIVATE
        )

        findViewById<Button>(R.id.btnCargar).setOnClickListener {
            startActivity(Intent(this, AppPreferenciasActivity::class.java))
        }

        findViewById<Button>(R.id.btnMostrar).setOnClickListener {
            val checkbox = if (prefs.getBoolean("checkboxPref", false)) "marcado" else "no marcado"
            val editText = prefs.getString("editTextPref", "sin valor")
            val secondEdit = prefs.getString("secondEditTextPref", "sin valor")

            Toast.makeText(
                this,
                "Checkbox: $checkbox\nEditText: $editText\nSecondEdit: $secondEdit",
                Toast.LENGTH_LONG
            ).show()
        }

        findViewById<Button>(R.id.btnModificar).setOnClickListener {
            val nuevoValor = txtString.text.toString()
            prefs.edit().putString("editTextPref", nuevoValor).apply()

            Toast.makeText(
                this,
                "Valor modificado: $nuevoValor",
                Toast.LENGTH_SHORT
            ).show()
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        val adapter = ImagenAdapter(imagenes) { position ->
            imageView.setImageResource(imagenes[position])
        }

        recyclerView.adapter = adapter

        if (imagenes.isNotEmpty()) {
            imageView.setImageResource(imagenes[0])
        }
    }
}