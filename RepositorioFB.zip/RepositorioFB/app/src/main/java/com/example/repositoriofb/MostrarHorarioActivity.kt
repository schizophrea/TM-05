package com.example.repositoriofb

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MostrarHorarioActivity : AppCompatActivity() {

    private lateinit var contenedorHorario: LinearLayout
    private lateinit var btnVolver: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrar_horario)

        contenedorHorario = findViewById(R.id.contenedorHorario)
        btnVolver = findViewById(R.id.btnVolver)

        btnVolver.setOnClickListener {
            finish()
        }

        cargarHorario()
    }

    private fun cargarHorario() {
        val ref = FirebaseDatabase.getInstance()
            .getReference("Clases")
            .child("Lecciones")

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                contenedorHorario.removeAllViews()

                if (!snapshot.exists()) {
                    mostrarMensajeVacio()
                    return
                }

                for (dato in snapshot.children) {
                    val clase = dato.getValue(Clase::class.java)

                    if (clase != null) {
                        agregarTarjeta(clase)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                contenedorHorario.removeAllViews()

                val txtError = TextView(this@MostrarHorarioActivity)
                txtError.text = "Error al cargar datos: ${error.message}"
                txtError.setTextColor(Color.WHITE)
                txtError.textSize = 16f

                contenedorHorario.addView(txtError)
            }
        })
    }

    private fun agregarTarjeta(clase: Clase) {
        val tarjeta = LinearLayout(this)
        tarjeta.orientation = LinearLayout.VERTICAL
        tarjeta.setPadding(28, 24, 28, 24)
        tarjeta.setBackgroundColor(Color.parseColor("#1D252D"))

        val paramsTarjeta = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        paramsTarjeta.setMargins(0, 0, 0, 22)
        tarjeta.layoutParams = paramsTarjeta

        val txtCurso = TextView(this)
        txtCurso.text = clase.area
        txtCurso.setTextColor(Color.WHITE)
        txtCurso.textSize = 20f
        txtCurso.setTypeface(null, Typeface.BOLD)

        val txtSeccion = TextView(this)
        txtSeccion.text = "Sección: ${clase.seccion}"
        txtSeccion.setTextColor(Color.parseColor("#AAB4BE"))
        txtSeccion.textSize = 15f
        txtSeccion.setPadding(0, 12, 0, 0)

        val txtTema = TextView(this)
        txtTema.text = "Tema: ${clase.tema}"
        txtTema.setTextColor(Color.parseColor("#DDE3EA"))
        txtTema.textSize = 15f
        txtTema.setPadding(0, 8, 0, 0)

        tarjeta.addView(txtCurso)
        tarjeta.addView(txtSeccion)
        tarjeta.addView(txtTema)

        contenedorHorario.addView(tarjeta)
    }

    private fun mostrarMensajeVacio() {
        val txtVacio = TextView(this)
        txtVacio.text = "Todavía no hay clases registradas."
        txtVacio.setTextColor(Color.WHITE)
        txtVacio.textSize = 16f

        contenedorHorario.addView(txtVacio)
    }
}