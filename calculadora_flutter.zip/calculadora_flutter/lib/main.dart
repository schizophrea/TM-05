import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const CalculadoraApp());
}

class CalculadoraApp extends StatelessWidget {
  const CalculadoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora Flutter',
      debugShowCheckedModeBanner: false,
      home: const CalculadoraPage(),
    );
  }
}

class CalculadoraPage extends StatefulWidget {
  const CalculadoraPage({super.key});

  @override
  State<CalculadoraPage> createState() => _CalculadoraPageState();
}

class _CalculadoraPageState extends State<CalculadoraPage> {
  final TextEditingController numero1Controller = TextEditingController();
  final TextEditingController numero2Controller = TextEditingController();

  String resultado = 'Resultado:';

  void calcular(String operacion) {
    double? numero1 = double.tryParse(numero1Controller.text);
    double? numero2 = double.tryParse(numero2Controller.text);

    if (operacion == 'raiz') {
      if (numero1 == null) {
        setState(() {
          resultado = 'Ingrese un número válido en el primer campo.';
        });
        return;
      }

      if (numero1 < 0) {
        setState(() {
          resultado = 'Error: no se puede calcular raíz de un número negativo.';
        });
        return;
      }

      setState(() {
        resultado = 'Resultado: ${sqrt(numero1).toStringAsFixed(2)}';
      });
      return;
    }

    if (numero1 == null || numero2 == null) {
      setState(() {
        resultado = 'Ingrese valores válidos en ambos campos.';
      });
      return;
    }

    double respuesta = 0;

    switch (operacion) {
      case 'suma':
        respuesta = numero1 + numero2;
        break;

      case 'resta':
        respuesta = numero1 - numero2;
        break;

      case 'multiplicacion':
        respuesta = numero1 * numero2;
        break;

      case 'division':
        if (numero2 == 0) {
          setState(() {
            resultado = 'Error: no se puede dividir entre cero.';
          });
          return;
        }
        respuesta = numero1 / numero2;
        break;

      case 'potencia':
        respuesta = pow(numero1, numero2).toDouble();
        break;
    }

    setState(() {
      resultado = 'Resultado: ${respuesta.toStringAsFixed(2)}';
    });
  }

  void limpiar() {
    numero1Controller.clear();
    numero2Controller.clear();

    setState(() {
      resultado = 'Resultado:';
    });
  }

  @override
  void dispose() {
    numero1Controller.dispose();
    numero2Controller.dispose();
    super.dispose();
  }

  Widget campoNumero(String texto, TextEditingController controller) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(
        decimal: true,
        signed: true,
      ),
      decoration: InputDecoration(
        labelText: texto,
        border: const OutlineInputBorder(),
      ),
    );
  }

  Widget botonOperacion(String texto, String operacion) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          calcular(operacion);
        },
        child: Text(texto),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        title: const Text('Calculadora en Flutter'),
        centerTitle: true,
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.calculate,
              size: 80,
              color: Colors.blue,
            ),

            const SizedBox(height: 20),

            campoNumero('Primer número', numero1Controller),

            const SizedBox(height: 15),

            campoNumero('Segundo número', numero2Controller),

            const SizedBox(height: 10),

            const Text(
              'Nota: para raíz cuadrada solo se usa el primer número.',
              style: TextStyle(fontSize: 14),
            ),

            const SizedBox(height: 25),

            botonOperacion('Sumar', 'suma'),

            const SizedBox(height: 10),

            botonOperacion('Restar', 'resta'),

            const SizedBox(height: 10),

            botonOperacion('Multiplicar', 'multiplicacion'),

            const SizedBox(height: 10),

            botonOperacion('Dividir', 'division'),

            const SizedBox(height: 10),

            botonOperacion('Potencia', 'potencia'),

            const SizedBox(height: 10),

            botonOperacion('Raíz cuadrada', 'raiz'),

            const SizedBox(height: 25),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue),
              ),
              child: Text(
                resultado,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: limpiar,
                child: const Text('Limpiar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}