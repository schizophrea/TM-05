package com.example.actividad_03

import android.content.Intent
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class SegundaActividad : AppCompatActivity() {

    private val TIMER_RUNTIME = 4000
    private var activo = false
    private lateinit var progressBar: ProgressBar
    private lateinit var txtEstado: TextView

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar
    private lateinit var toggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_actividad)

        toolbar = findViewById(R.id.toolbar)
        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)
        progressBar = findViewById(R.id.progressBar)
        txtEstado = findViewById(R.id.txtEstado)

        setSupportActionBar(toolbar)

        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.open_drawer,
            R.string.close_drawer
        )

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }
                R.id.nav_conversion -> {
                    startActivity(Intent(this, ConversionActivity::class.java))
                    true
                }
                R.id.nav_salir -> {
                    finish()
                    true
                }
                else -> false
            }.also {
                drawerLayout.closeDrawers()
            }
        }

        iniciarCarga()
    }

    private fun iniciarCarga() {
        val hilo = Thread {
            activo = true
            var tiempo = 0

            while (activo && tiempo < TIMER_RUNTIME) {
                Thread.sleep(200)
                tiempo += 200
                actualizarProgress(tiempo)
            }

            runOnUiThread {
                txtEstado.text = "Carga completa"
            }
        }
        hilo.start()
    }

    private fun actualizarProgress(tiempoPasado: Int) {
        val progreso = progressBar.max * tiempoPasado / TIMER_RUNTIME
        runOnUiThread {
            progressBar.progress = progreso
        }
    }
}