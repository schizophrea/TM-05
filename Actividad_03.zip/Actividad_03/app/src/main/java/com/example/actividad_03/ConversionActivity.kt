package com.example.actividad_03

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class ConversionActivity : AppCompatActivity() {

    private lateinit var edtMonto: EditText
    private lateinit var spMoneda: Spinner
    private lateinit var btnConvertir: Button
    private lateinit var txtResultado: TextView

    private lateinit var progressBarCarga: ProgressBar
    private lateinit var txtEstado: TextView
    private lateinit var cardCarga: CardView
    private lateinit var cardConversion: CardView

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar
    private lateinit var toggle: ActionBarDrawerToggle

    private val tiempoCarga = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conversion)

        toolbar = findViewById(R.id.toolbar)
        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        progressBarCarga = findViewById(R.id.progressBarCarga)
        txtEstado = findViewById(R.id.txtEstado)
        cardCarga = findViewById(R.id.cardCarga)
        cardConversion = findViewById(R.id.cardConversion)

        edtMonto = findViewById(R.id.edtMonto)
        spMoneda = findViewById(R.id.spMoneda)
        btnConvertir = findViewById(R.id.btnConvertir)
        txtResultado = findViewById(R.id.txtResultado)

        setSupportActionBar(toolbar)

        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.open_drawer,
            R.string.close_drawer
        )

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }

                R.id.nav_conversion -> {
                    drawerLayout.closeDrawers()
                    true
                }

                R.id.nav_salir -> {
                    finish()
                    true
                }

                else -> false
            }.also {
                drawerLayout.closeDrawers()
            }
        }

        val opciones = arrayOf(
            "Soles a Dólares",
            "Dólares a Soles",
            "Soles a Euros",
            "Euros a Soles"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opciones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spMoneda.adapter = adapter

        btnConvertir.setOnClickListener {
            convertir()
        }

        iniciarCarga()
    }

    private fun iniciarCarga() {
        Thread {
            var tiempo = 0
            while (tiempo < tiempoCarga) {
                Thread.sleep(200)
                tiempo += 200
                actualizarProgreso(tiempo)
            }

            runOnUiThread {
                txtEstado.text = "Carga completa"
            }

            Thread.sleep(700)

            runOnUiThread {
                cardCarga.visibility = View.GONE
                cardConversion.visibility = View.VISIBLE
            }
        }.start()
    }

    private fun actualizarProgreso(tiempoPasado: Int) {
        val progreso = progressBarCarga.max * tiempoPasado / tiempoCarga
        runOnUiThread {
            progressBarCarga.progress = progreso
        }
    }

    private fun convertir() {
        val texto = edtMonto.text.toString()

        if (texto.isEmpty()) {
            txtResultado.text = "Resultado: ingrese un monto"
            return
        }

        val monto = texto.toDouble()
        val resultado = when (spMoneda.selectedItemPosition) {
            0 -> monto / 3.75
            1 -> monto * 3.75
            2 -> monto / 4.10
            3 -> monto * 4.10
            else -> 0.0
        }

        txtResultado.text = "Resultado: %.2f".format(resultado)
    }
}