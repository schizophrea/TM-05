package com.example.ejercicio40

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val nombres = arrayOf(
        "Pedro",
        "Pedrito",
        "Pedro Pablo",
        "Percy",
        "Piero",
        "Pamela",
        "Paola",
        "Patricia",
        "Pablo"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtNombre = findViewById<AutoCompleteTextView>(R.id.txtNombre)
        val btnEvaluar = findViewById<Button>(R.id.btnMostrar)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            nombres
        )

        txtNombre.setAdapter(adapter)
        txtNombre.threshold = 1

        txtNombre.setOnClickListener {
            txtNombre.showDropDown()
        }

        // 👇 AQUÍ ESTÁ LA VALIDACIÓN (APTO / NO APTO)
        btnEvaluar.setOnClickListener {

            val nombre = txtNombre.text.toString()

            if (nombre.isEmpty()) {
                txtResultado.text = "Ingrese un nombre"
            } else {

                // 🔥 Lógica de ejemplo (puedes cambiarla)
                val apto = nombre.startsWith("P") // ejemplo simple

                if (apto) {
                    txtResultado.text = "✔ APTO → Enviar a Caja (Pago)"
                } else {
                    txtResultado.text = "❌ NO APTO → Devolver a Contabilidad"
                }
            }
        }
    }
}