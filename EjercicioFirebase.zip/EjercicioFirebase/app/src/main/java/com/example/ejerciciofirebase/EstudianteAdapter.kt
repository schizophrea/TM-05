package com.example.ejerciciofirebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EstudianteAdapter(
    private val listaEstudiantes: MutableList<Estudiante>
) : RecyclerView.Adapter<EstudianteAdapter.EstudianteViewHolder>() {

    class EstudianteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtItemNombre: TextView = itemView.findViewById(R.id.txtItemNombre)
        val txtItemCarrera: TextView = itemView.findViewById(R.id.txtItemCarrera)
        val txtItemCurso: TextView = itemView.findViewById(R.id.txtItemCurso)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EstudianteViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_estudiante, parent, false)

        return EstudianteViewHolder(vista)
    }

    override fun onBindViewHolder(holder: EstudianteViewHolder, position: Int) {
        val estudiante = listaEstudiantes[position]

        holder.txtItemNombre.text = estudiante.nombre
        holder.txtItemCarrera.text = "Carrera: ${estudiante.carrera}"
        holder.txtItemCurso.text = "Curso: ${estudiante.curso}"
    }

    override fun getItemCount(): Int {
        return listaEstudiantes.size
    }
}