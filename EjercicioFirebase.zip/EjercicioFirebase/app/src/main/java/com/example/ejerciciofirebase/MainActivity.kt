package com.example.ejerciciofirebase

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    private lateinit var txtNombre: EditText
    private lateinit var spinCarrera: Spinner
    private lateinit var spinCurso: Spinner
    private lateinit var btnGuardar: Button
    private lateinit var rvEstudiantes: RecyclerView

    private lateinit var estudiantesRef: DatabaseReference
    private lateinit var adapter: EstudianteAdapter

    private val listaEstudiantes = mutableListOf<Estudiante>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtNombre = findViewById(R.id.txtNombre)
        spinCarrera = findViewById(R.id.spinCarrera)
        spinCurso = findViewById(R.id.spinCurso)
        btnGuardar = findViewById(R.id.btnGuardar)
        rvEstudiantes = findViewById(R.id.rvEstudiantes)

        estudiantesRef = FirebaseDatabase.getInstance().getReference("Estudiantes")

        adapter = EstudianteAdapter(listaEstudiantes)

        rvEstudiantes.layoutManager = LinearLayoutManager(this)
        rvEstudiantes.adapter = adapter

        btnGuardar.setOnClickListener {
            guardarEstudiante()
        }

        mostrarEstudiantes()
    }

    private fun guardarEstudiante() {
        val nombre = txtNombre.text.toString().trim()
        val carrera = spinCarrera.selectedItem.toString()
        val curso = spinCurso.selectedItem.toString()

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Ingrese el nombre del estudiante", Toast.LENGTH_SHORT).show()
            return
        }

        val id = estudiantesRef.push().key

        if (id == null) {
            Toast.makeText(this, "No se pudo generar el ID", Toast.LENGTH_SHORT).show()
            return
        }

        val estudiante = Estudiante(
            id = id,
            nombre = nombre,
            carrera = carrera,
            curso = curso
        )

        estudiantesRef.child(id).setValue(estudiante)
            .addOnSuccessListener {
                Toast.makeText(this, "Estudiante guardado", Toast.LENGTH_SHORT).show()
                txtNombre.text.clear()
                spinCarrera.setSelection(0)
                spinCurso.setSelection(0)
            }
            .addOnFailureListener { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun mostrarEstudiantes() {
        estudiantesRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                listaEstudiantes.clear()

                for (dato in snapshot.children) {
                    val estudiante = dato.getValue(Estudiante::class.java)

                    if (estudiante != null) {
                        estudiante.id = dato.key ?: ""
                        listaEstudiantes.add(estudiante)
                    }
                }

                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    this@MainActivity,
                    "Error al mostrar datos: ${error.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }
}