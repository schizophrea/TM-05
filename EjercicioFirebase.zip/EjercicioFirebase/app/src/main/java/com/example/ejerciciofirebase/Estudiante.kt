package com.example.ejerciciofirebase

data class Estudiante(
    var id: String = "",
    var nombre: String = "",
    var carrera: String = "",
    var curso: String = ""
)