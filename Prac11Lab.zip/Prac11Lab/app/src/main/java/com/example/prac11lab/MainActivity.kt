package com.example.prac11lab

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.prac11lab.databinding.ActivityMainBinding
import com.google.mlkit.nl.smartreply.SmartReply
import com.google.mlkit.nl.smartreply.SmartReplySuggestionResult
import com.google.mlkit.nl.smartreply.TextMessage
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val conversation = ArrayList<TextMessage>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.sendButton.setOnClickListener {
            addMessage()
        }

        binding.hintsButton.setOnClickListener {
            getSmartReplies()
        }

        binding.clearButton.setOnClickListener {
            clearConversation()
        }

        binding.hint0Button.setOnClickListener {
            useSuggestion(binding.hint0Button.text.toString())
        }

        binding.hint1Button.setOnClickListener {
            useSuggestion(binding.hint1Button.text.toString())
        }

        binding.hint2Button.setOnClickListener {
            useSuggestion(binding.hint2Button.text.toString())
        }
    }

    private fun addMessage() {
        val name = binding.nameText.text.toString().trim()
        val message = binding.messageText.text.toString().trim()

        if (name.isEmpty()) {
            binding.errorText.text = "Ingresa el nombre del contacto."
            return
        }

        if (message.isEmpty()) {
            binding.errorText.text = "Escribe un mensaje."
            return
        }

        conversation.add(
            TextMessage.createForRemoteUser(
                message,
                System.currentTimeMillis(),
                name
            )
        )

        showMessageInChat(name, message)
        binding.messageText.setText("")
        binding.errorText.text = ""
        hideSuggestions()
    }

    private fun getSmartReplies() {
        if (conversation.isEmpty()) {
            binding.errorText.text = "Primero envía un mensaje para generar sugerencias."
            return
        }

        val smartReply = SmartReply.getClient()

        smartReply.suggestReplies(conversation)
            .addOnSuccessListener { result ->

                when (result.status) {
                    SmartReplySuggestionResult.STATUS_SUCCESS -> {
                        if (result.suggestions.isNotEmpty()) {
                            binding.errorText.text = ""

                            val suggestions = result.suggestions

                            binding.hint0Button.text = suggestions.getOrNull(0)?.text ?: ""
                            binding.hint1Button.text = suggestions.getOrNull(1)?.text ?: ""
                            binding.hint2Button.text = suggestions.getOrNull(2)?.text ?: ""

                            binding.hint0Button.visibility =
                                if (binding.hint0Button.text.isNotEmpty()) View.VISIBLE else View.GONE

                            binding.hint1Button.visibility =
                                if (binding.hint1Button.text.isNotEmpty()) View.VISIBLE else View.GONE

                            binding.hint2Button.visibility =
                                if (binding.hint2Button.text.isNotEmpty()) View.VISIBLE else View.GONE
                        } else {
                            binding.errorText.text = "No se encontraron sugerencias."
                        }
                    }

                    SmartReplySuggestionResult.STATUS_NOT_SUPPORTED_LANGUAGE -> {
                        binding.errorText.text = "Idioma no soportado. Prueba con mensajes en inglés."
                        Toast.makeText(this, "Idioma no soportado", Toast.LENGTH_SHORT).show()
                    }

                    else -> {
                        binding.errorText.text = "No se pudo generar una respuesta."
                    }
                }
            }
            .addOnFailureListener { exception ->
                binding.errorText.text = "Error: ${exception.message}"
            }
    }

    private fun useSuggestion(text: String) {
        if (text.isEmpty()) return

        conversation.add(
            TextMessage.createForLocalUser(
                text,
                System.currentTimeMillis()
            )
        )

        showMessageInChat("Tú", text)
        hideSuggestions()
    }

    private fun showMessageInChat(name: String, message: String) {
        val textView = TextView(this)

        textView.text = "$name: $message"
        textView.textSize = 15f
        textView.setTextColor(getColor(android.R.color.white))
        textView.setPadding(18, 14, 18, 14)
        textView.setBackgroundResource(R.drawable.bg_message)

        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        params.setMargins(0, 0, 0, 12)
        textView.layoutParams = params

        binding.chatContainer.addView(textView)
    }

    private fun clearConversation() {
        conversation.clear()

        binding.nameText.setText("")
        binding.messageText.setText("")
        binding.errorText.text = ""
        binding.chatContainer.removeAllViews()

        hideSuggestions()
    }

    private fun hideSuggestions() {
        binding.hint0Button.visibility = View.GONE
        binding.hint1Button.visibility = View.GONE
        binding.hint2Button.visibility = View.GONE
    }
}