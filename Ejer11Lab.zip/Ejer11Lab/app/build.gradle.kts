plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.ejer11lab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.ejer11lab"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")

    val cameraxVersion = "1.5.1"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
}