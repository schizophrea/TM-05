package com.example.ejer11lab

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.ejer11lab.databinding.ActivityMainBinding
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var cameraExecutor: ExecutorService

    private var lastCodeValue: String? = null

    private val requestCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                binding.statusText.text = "Estado: cámara activa. Apunta al código."
                startCamera()
            } else {
                binding.statusText.text = "Estado: permiso de cámara denegado."
                Toast.makeText(this, "Se necesita permiso de cámara", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.clearButton.setOnClickListener {
            lastCodeValue = null
            binding.resultText.text = "Resultado del código"
            binding.statusText.text = "Estado: listo para escanear nuevamente."
        }

        checkCameraPermission()
    }

    private fun checkCameraPermission() {
        val permission = Manifest.permission.CAMERA

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            binding.statusText.text = "Estado: cámara activa. Apunta al código."
            startCamera()
        } else {
            binding.statusText.text = "Estado: solicitando permiso de cámara..."
            requestCameraPermission.launch(permission)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder()
                .build()
                .also { cameraPreview ->
                    cameraPreview.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            val analyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { imageAnalysis ->
                    imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                        processImageProxy(imageProxy)
                    }
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()

                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    analyzer
                )

            } catch (exception: Exception) {
                binding.statusText.text = "Error al iniciar la cámara: ${exception.message}"
            }

        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun processImageProxy(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image

        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val image = InputImage.fromMediaImage(
            mediaImage,
            imageProxy.imageInfo.rotationDegrees
        )

        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_QR_CODE,
                Barcode.FORMAT_CODE_128,
                Barcode.FORMAT_EAN_13,
                Barcode.FORMAT_UPC_A,
                Barcode.FORMAT_PDF417
            )
            .build()

        val scanner = BarcodeScanning.getClient(options)

        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                readBarcodes(barcodes)
            }
            .addOnFailureListener { exception ->
                runOnUiThread {
                    binding.statusText.text = "Error al escanear: ${exception.message}"
                }
            }
            .addOnCompleteListener {
                imageProxy.close()
            }
    }

    private fun readBarcodes(barcodes: List<Barcode>) {
        if (barcodes.isEmpty()) return

        val barcode = barcodes.first()
        val value = barcode.rawValue ?: return

        if (value == lastCodeValue) return

        lastCodeValue = value

        runOnUiThread {
            binding.resultText.text = value
            binding.statusText.text = "Estado: código detectado correctamente."
            Toast.makeText(this, "Código detectado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}