package com.example.lab07_arctividad

import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileNotFoundException

class MainActivity : AppCompatActivity() {

    private lateinit var editText: EditText

    private lateinit var btnSave: Button
    private lateinit var btnLoad: Button
    private lateinit var btnGuardarExterno: Button
    private lateinit var btnCargarExterno: Button

    private val nombreArchivoInterno = "textfile.txt"
    private val nombreArchivoExterno = "archivo_externo.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.editText)

        btnSave = findViewById(R.id.btnSave)
        btnLoad = findViewById(R.id.btnLoad)
        btnGuardarExterno = findViewById(R.id.btnGuardarExterno)
        btnCargarExterno = findViewById(R.id.btnCargarExterno)

        btnSave.setOnClickListener {
            guardarArchivoInterno()
        }

        btnLoad.setOnClickListener {
            cargarArchivoInterno()
        }

        btnGuardarExterno.setOnClickListener {
            guardarArchivoExterno()
        }

        btnCargarExterno.setOnClickListener {
            cargarArchivoExterno()
        }
    }

    private fun guardarArchivoInterno() {
        val texto = editText.text.toString()

        if (texto.isEmpty()) {
            Toast.makeText(this, "Escribe algo primero", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            openFileOutput(nombreArchivoInterno, Context.MODE_PRIVATE).use { archivo ->
                archivo.write(texto.toByteArray())
            }

            editText.setText("")
            Toast.makeText(this, "Archivo interno guardado correctamente", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al guardar archivo interno", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cargarArchivoInterno() {
        try {
            val contenido = openFileInput(nombreArchivoInterno).bufferedReader().use { reader ->
                reader.readText()
            }

            editText.setText(contenido)
            Toast.makeText(this, "Archivo interno cargado correctamente", Toast.LENGTH_SHORT).show()

        } catch (e: FileNotFoundException) {
            Toast.makeText(this, "Todavía no existe el archivo interno", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar archivo interno", Toast.LENGTH_SHORT).show()
        }
    }

    private fun guardarArchivoExterno() {
        val texto = editText.text.toString()

        if (texto.isEmpty()) {
            Toast.makeText(this, "Escribe algo primero", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val carpeta = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)

            if (carpeta == null) {
                Toast.makeText(this, "No se encontró almacenamiento externo", Toast.LENGTH_SHORT).show()
                return
            }

            val archivo = File(carpeta, nombreArchivoExterno)
            archivo.writeText(texto)

            editText.setText("")
            Toast.makeText(this, "Archivo externo guardado correctamente", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al guardar archivo externo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cargarArchivoExterno() {
        try {
            val carpeta = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)

            if (carpeta == null) {
                Toast.makeText(this, "No se encontró almacenamiento externo", Toast.LENGTH_SHORT).show()
                return
            }

            val archivo = File(carpeta, nombreArchivoExterno)

            if (!archivo.exists()) {
                Toast.makeText(this, "Todavía no existe el archivo externo", Toast.LENGTH_SHORT).show()
                return
            }

            val contenido = archivo.readText()
            editText.setText(contenido)

            Toast.makeText(this, "Archivo externo cargado correctamente", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar archivo externo", Toast.LENGTH_SHORT).show()
        }
    }
}